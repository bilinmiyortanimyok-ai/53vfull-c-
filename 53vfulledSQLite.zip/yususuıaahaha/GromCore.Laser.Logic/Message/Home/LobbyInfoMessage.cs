using System;
using GromCore.Laser.Logic.Home;

namespace GromCore.Laser.Logic.Message.Home
{
    public class LobbyInfoMessage : GameMessage
    {
        private readonly int _playerCount;
        public HomeMode player;

        public string LobbyData { get; set; }
        public int PlayersCount { get; set; }
        public int PingMs { get; set; }

        public LobbyInfoMessage()
        {
            _playerCount = 0;
            LobbyData = string.Empty;
            PlayersCount = 0;
            PingMs = 0;
        }

        public LobbyInfoMessage(int playerCount)
        {
            _playerCount = playerCount;
            LobbyData = string.Empty;
            PlayersCount = 0;
            PingMs = 0;
        }

        public LobbyInfoMessage(string lobbyData, int playersCount)
        {
            _playerCount = playersCount;
            LobbyData = lobbyData ?? string.Empty;
            PlayersCount = playersCount;
            PingMs = 0;
        }

        public LobbyInfoMessage(string lobbyData, int playersCount, int pingMs)
        {
            _playerCount = playersCount;
            LobbyData = lobbyData ?? string.Empty;
            PlayersCount = playersCount;
            PingMs = pingMs;
        }

        public override void Encode()
        {
            try
            {
                int countToSend = PlayersCount > 0 ? PlayersCount : _playerCount;

                // Oyuncu sayısını gönder.
                Stream.WriteVInt(countToSend);

                // Ana menüye özel/debug yazılar ekleme.
                // LobbyData başka bir yerden ayarlanmışsa sadece onu gönder.
                Stream.WriteString(LobbyData ?? string.Empty);

                // Mesajın sonundaki mevcut alan.
                Stream.WriteVInt(0);
            }
            catch (Exception ex)
            {
                GromCore.Laser.Titan.Debug.Debugger.Print(
                    $"LobbyInfoMessage Encode error: {ex.Message}");

                Stream.WriteVInt(0);
                Stream.WriteString(string.Empty);
                Stream.WriteVInt(0);
            }
        }

        public override int GetMessageType()
        {
            return 23457;
        }

        public override int GetServiceNodeType()
        {
            return 9;
        }
    }
}
