namespace GromCore.Laser.Server.Database
{
    using Microsoft.Data.Sqlite;

    internal static class SqliteDatabase
    {
        private static readonly object Sync = new object();
        private static bool Initialized;
        public static string DatabasePath { get; } = Path.GetFullPath(
            Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "gromcore.db"));

        public static string ConnectionString => new SqliteConnectionStringBuilder
        {
            DataSource = DatabasePath,
            Mode = SqliteOpenMode.ReadWriteCreate,
            Cache = SqliteCacheMode.Shared,
            DefaultTimeout = 30
        }.ToString();

        public static void Initialize()
        {
            lock (Sync)
            {
                if (Initialized) return;
                Directory.CreateDirectory(Path.GetDirectoryName(DatabasePath)!);
                using var connection = new SqliteConnection(ConnectionString);
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = "PRAGMA journal_mode=WAL;";
                command.ExecuteNonQuery();
                command.CommandText = "PRAGMA synchronous=NORMAL;";
                command.ExecuteNonQuery();
                command.CommandText = @"
CREATE TABLE IF NOT EXISTS accounts (
    ""Id"" INTEGER NOT NULL PRIMARY KEY,
    ""Trophies"" INTEGER NOT NULL DEFAULT 0,
    ""Data"" TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_accounts_trophies ON accounts(""Trophies"");
CREATE TABLE IF NOT EXISTS alliances (
    ""Id"" INTEGER NOT NULL PRIMARY KEY,
    ""Name"" TEXT NOT NULL,
    ""Trophies"" INTEGER NOT NULL DEFAULT 0,
    ""Data"" TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_alliances_trophies ON alliances(""Trophies"");
CREATE INDEX IF NOT EXISTS idx_alliances_name ON alliances(""Name"");
CREATE TABLE IF NOT EXISTS account_links (
    ""AccountId"" INTEGER NOT NULL PRIMARY KEY,
    ""AccountLogin"" TEXT NOT NULL,
    ""AccountEmail"" TEXT DEFAULT NULL,
    ""AccountPassword"" TEXT NOT NULL,
    ""AccountLinkedToTelegram"" INTEGER NOT NULL DEFAULT 0,
    ""AccountTelegramLinkedId"" INTEGER DEFAULT NULL,
    ""LinkToken"" TEXT DEFAULT NULL,
    ""VerificationCode"" INTEGER DEFAULT NULL,
    ""VerificationCodeAlive"" TEXT DEFAULT NULL,
    ""TelegramLinkCode"" TEXT DEFAULT NULL,
    ""TelegramLinkCodeExpire"" TEXT DEFAULT NULL
);";
                command.ExecuteNonQuery();
                Initialized = true;
            }
        }

        public static void BackupTo(string destinationPath)
        {
            Initialize();
            string fullPath = Path.GetFullPath(destinationPath);
            Directory.CreateDirectory(Path.GetDirectoryName(fullPath)!);
            using var source = new SqliteConnection(ConnectionString);
            using var destination = new SqliteConnection(new SqliteConnectionStringBuilder
            {
                DataSource = fullPath,
                Mode = SqliteOpenMode.ReadWriteCreate,
                DefaultTimeout = 30
            }.ToString());
            source.Open();
            destination.Open();
            source.BackupDatabase(destination);
        }
    }
}
