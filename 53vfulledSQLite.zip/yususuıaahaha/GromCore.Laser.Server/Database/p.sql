-- SQLite schema. The application creates this schema automatically at startup.
CREATE TABLE IF NOT EXISTS accounts (
    "Id" INTEGER NOT NULL PRIMARY KEY,
    "Trophies" INTEGER NOT NULL DEFAULT 0,
    "Data" TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_accounts_trophies ON accounts("Trophies");
CREATE TABLE IF NOT EXISTS alliances (
    "Id" INTEGER NOT NULL PRIMARY KEY,
    "Name" TEXT NOT NULL,
    "Trophies" INTEGER NOT NULL DEFAULT 0,
    "Data" TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_alliances_trophies ON alliances("Trophies");
CREATE INDEX IF NOT EXISTS idx_alliances_name ON alliances("Name");
